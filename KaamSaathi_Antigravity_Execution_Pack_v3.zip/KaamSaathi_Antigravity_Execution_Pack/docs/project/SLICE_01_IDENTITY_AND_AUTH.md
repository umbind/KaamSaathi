# Vertical Slice 1 — Identity, Role, and Onboarding

Status: `NOT_STARTED`
Owner: @orchestrator (assigns @backend, @android, @architect, @ux as needed)
Depends on: Phase 3 architecture contracts frozen (auth service boundary, session/token format, user schema)
Blocks: every other slice (all require an authenticated actor)

This is the first slice in the Phase 5 sequence in the master execution contract. Everything below must trace back to `FUNCTIONAL_WORKFLOW_SPEC.md`, `STATE_MACHINES.md` §2, and `ROLE_PERMISSION_MATRIX.md`.

---

## 1. In scope

- **C-01** First launch and language selection (Hindi/English, no forced permissions, no forced marketing consent).
- **C-02** Mobile OTP registration and login, including resend/cooldown, generic response regardless of registration status, attempt/expiry/replay handling.
- **C-03** Customer profile creation and shared-device privacy (visible logout, optional app PIN, masked notifications).
- **P-01** Provider role activation (a customer account adding a provider profile) and role switching between the two, per the Role-Switch Rules in `ROLE_PERMISSION_MATRIX.md`.
- User Account State machine (`STATE_MACHINES.md` §2): `PENDING_PHONE_VERIFICATION` → `ACTIVE`, and the account-level actions reachable from onboarding (`DEACTIVATED_BY_USER` entry point only — restriction/suspension/deletion states are Slice 7, admin/privacy scope).
- Admin/privileged-admin login with mandatory MFA (needed so later admin-facing slices aren't blocked, and so audit logging has an authenticated actor from day one).
- Server-side session issuance and refresh; re-authentication trigger for high-risk actions (the trigger *mechanism*, not every high-risk action that will use it later — those get built per-slice).

## 2. Explicitly out of scope for this slice

- Provider verification review workflow (P-06 onward) — only the profile *shell* and role flag are created here.
- Any service-category, location-radius, or availability data — that's Slice 2.
- Real SMS/OTP vendor integration — build and test against the mock OTP provider (see §4).
- Account restriction, suspension, deletion, and legal-hold states — Slice 7 (admin/privacy).
- Assisted-operator-driven onboarding — same functional shape, but deferred so the operator consent/audit mechanism isn't built twice; revisit once support tooling exists.

## 3. Acceptance criteria (testable)

1. A new user can complete C-01 → C-02 → C-03 in under 60 seconds on a simulated low-end device/network profile, with no permission prompts before language selection.
2. The OTP endpoint returns an identical response shape and timing envelope for a registered and an unregistered number (anti-enumeration).
3. OTP has a bounded attempt count, an expiry, and rejects replay; exceeding attempts triggers rate-limiting, not account lockout of an unrelated user.
4. A session survives app restart; a revoked/expired session forces re-authentication without losing local draft data.
5. A customer account can activate a provider profile without losing customer data, and switching modes changes the visible capability set to exactly the Customer or Provider column in `ROLE_PERMISSION_MATRIX.md` — verified by an automated test that asserts the *complement* is denied (e.g., in customer mode, provider-only endpoints return authorization errors, not just absent UI).
6. An account cannot select or transact with its own provider profile as a customer (self-dealing exclusion) — covered by an explicit test case, not just code review.
7. Every state transition in this slice writes an audit record with actor, previous state, new state, timestamp, and correlation ID, per the State-Machine Contract in `STATE_MACHINES.md` §1.
8. Admin login enforces MFA with no bypass path; a shared/service admin account cannot be created through this flow.
9. Hindi and English both pass a native-reader content review for C-01–C-03 copy; language switch does not require re-registration.
10. Screen-reader semantics and text scaling (up to the platform's largest supported size) pass for every screen in this slice; no critical action is icon-only.

## 4. Mock OTP provider (dev/test only)

Per the master execution contract's dev/test carve-out: build an OTP provider interface with two implementations —

- `MockOtpProvider`: returns a fixed or logged code, sends nothing externally, used in local/dev/CI.
- `SmsOtpProvider`: real vendor integration, stubbed/unimplemented until a vendor is approved (Section 8 gate).

The rest of the auth flow (rate limiting, expiry, replay checks, anti-enumeration) must be implemented and tested identically regardless of which provider is wired in, so vendor selection later is a config change, not a rework.

## 5. Data and contracts touched

- User account table/schema (phone number hash/normalized form, not raw where avoidable; language preference; account state; MFA status for admin).
- Provider profile shell (empty except role flag and creation timestamp — full profile is Slice 2).
- Session/refresh token issuance and storage (Android secure storage; no token in logs).
- Audit event schema for account-state transitions (shared with later slices — freeze this contract now since every subsequent slice's audit trail depends on it).

## 6. Test matrix for this slice

- Unit: OTP validation logic (expiry, attempt count, replay), session issuance/refresh, role-switch authorization checks.
- Integration: full C-01→C-03 flow against `MockOtpProvider`; admin MFA flow.
- Security: anti-enumeration response-timing/shape test; rate-limit bypass attempts; token leakage in logs/crash reports; self-dealing exclusion test.
- Accessibility: screen-reader pass, text-scaling pass, color-only-status check.
- Localization: Hindi/English content review, layout check for text-length differences.
- Retry/offline: airplane-mode mid-OTP-entry, app-kill mid-registration, duplicate submit with same idempotency key.

## 7. Exit criteria

All items in §3 pass with evidence stored per the master contract's evidence rules (full bundle — this slice touches authentication, so it does not qualify for the lightweight tier). Independent review performed by an agent that did not author the change. Status moves to `VERIFIED` only after that review and a rerun of the critical test commands by the reviewer, not a rerun by the author.

## 8. Known dependency to flag now

Masked-calling vendor research (Phase 1, per Section 3.6 of the master contract) does not block this slice, but its outcome affects the session/consent audit schema this slice freezes in §5 — the consent-recording shape here should be generic enough to cover a future "reveal number" consent event without a schema migration. Note this as an assumption in `ASSUMPTIONS.md` when work starts.
